package com.example.demoproject.DAOTest;

import com.example.demoproject.DAORepository.FlightRepo;
import com.example.demoproject.Entity.FlightEntity;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@DataJpaTest
public class FlightRepoTest {


    @Autowired
    private TestEntityManager testEntityManager;

    @Autowired
    private FlightRepo flightRepo;

    @Test
    public void TestTofindByUPnrIsNull(){

        testEntityManager.persistAndFlush(buildFlightData());
        List<FlightEntity> list=flightRepo.findByUPnrIsNull();
        assertThat(list.size()).isEqualTo(1);
    }
    private FlightEntity buildFlightData()
    {
        FlightEntity flightEntity=new FlightEntity();
        flightEntity.setF_name("abc");
        flightEntity.setF_num("Pqrs");
        flightEntity.setU_email("abc@abc.com");
        flightEntity.setU_name("abcc");
        flightEntity.setuPnr(null);
        return flightEntity;
    }

   /* @Test
    public void TestToAddPnrToDatabase()
    {
        testEntityManager.persistAndFlush(buildFlightData());
        flightRepo.AddPnrToDatabase();


    }*/

   @Test
    public void showAllData()
   {
       testEntityManager.persistAndFlush(buildFlightData());
       List<FlightEntity> list=flightRepo.showAlldata();
       assertThat(list.size()).isEqualTo(1);

   }
}
