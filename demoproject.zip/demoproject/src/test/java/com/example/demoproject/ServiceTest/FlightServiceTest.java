package com.example.demoproject.ServiceTest;


import com.example.demoproject.DAORepository.FlightRepo;
import com.example.demoproject.Entity.FlightEntity;
import com.example.demoproject.Service.java.FlightService;
import org.junit.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;


import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;


@RunWith(SpringRunner.class)
public class FlightServiceTest {

    @Mock
    private FlightRepo flightRepo;


    @InjectMocks
    private FlightService flightService;


    @Test
    public void TestToGetDataFlightWithNullValues()
    {
        List<FlightEntity>list=new ArrayList<FlightEntity>();

        Mockito.when(flightRepo.findByUPnrIsNull()).thenReturn(getFlightDataa());
        list=flightService.getDataFlight();
        Assert.assertEquals(1,list.size());

    }
    private List<FlightEntity> getFlightDataa()
    {
        List<FlightEntity>list=new ArrayList<FlightEntity>();

        FlightEntity flightEntity=new FlightEntity();
        flightEntity.setF_name("abc");
        flightEntity.setF_num("Pqrs");
        flightEntity.setU_email("abc@abc.com");
        flightEntity.setU_name("abcc");

       list.add(flightEntity);
        return list;
    }

    @Test
    public void TestToGetDataFlightWithNoNullValues()
    {
        Mockito.when(flightRepo.findByUPnrIsNull()).thenReturn(Collections.emptyList());
        List<FlightEntity>list =flightService.getDataFlight();
        Assert.assertEquals(0,list.size());

    }


    @Test
    public void TestToShowAllData()
    {
        Mockito.when(flightRepo.showAlldata()).thenReturn(getFlightData());
        List<FlightEntity>list=flightService.showAllDataOfFlight();
        Assert.assertEquals(1,list.size());
    }

     private List<FlightEntity> getFlightData()
    {
        List<FlightEntity>list=new ArrayList<FlightEntity>();

        FlightEntity flightEntity=new FlightEntity();
        flightEntity.setF_name("abc");
        flightEntity.setF_num("Pqrs");
        flightEntity.setU_email("abc@abc.com");
        flightEntity.setU_name("abcc");
        flightEntity.setuPnr("QWW3J");

        list.add(flightEntity);
        return list;
    }






}
