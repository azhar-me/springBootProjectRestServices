package com.example.demoproject.ServiceTest;


import com.example.demoproject.DAORepository.HotelRepo;

import com.example.demoproject.Entity.HotelEntity;
import com.example.demoproject.Service.java.HotelService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@RunWith(SpringRunner.class)
public class HotelServiceTest {
    @Mock
    private HotelRepo hotelRepo;


    @InjectMocks
    private HotelService hotelService;

    @Test
    public void TestToGetDataHotelWithNullValues()
    {
        Mockito.when(hotelRepo.findByNullValues()).thenReturn(getHotelDataa());
        List<HotelEntity> list=hotelService.getDataOfHotel();
        Assert.assertEquals(1,list.size());

    }
    private List<HotelEntity> getHotelDataa()
    {
        List<HotelEntity>list=new ArrayList<HotelEntity>();

        HotelEntity hotelEntity=new HotelEntity();
       hotelEntity.setHotel_id(2);
       hotelEntity.setHotel_name("abc");
       hotelEntity.setHotel_BookingNumber(null);
       hotelEntity.setHotel_roomNumber(33);
       hotelEntity.setUser_email("abc@abc.com");
       hotelEntity.setUser_name("pqrs");
        list.add(hotelEntity);
        return list;
    }

    @Test
    public void TestToGetDataHotelWithNoNullValues()
    {
        Mockito.when(hotelRepo.findByNullValues()).thenReturn(Collections.emptyList());
        List<HotelEntity>list =hotelService.getDataOfHotel();
        Assert.assertEquals(0,list.size());

    }

    @Test
    public void TestToShowAllDataOfHotel()
    {
        Mockito.when(hotelRepo.showAlldata()).thenReturn(getHotelData());
        List<HotelEntity>list=hotelService.showAllDataOfHotel();
        Assert.assertEquals(1,list.size());
    }

    private List<HotelEntity> getHotelData()
    {
        List<HotelEntity>list=new ArrayList<HotelEntity>();

        HotelEntity hotelEntity=new HotelEntity();
        hotelEntity.setUser_name("abc");
        hotelEntity.setUser_email("abc@abc.com");
        hotelEntity.setHotel_roomNumber(12);
        hotelEntity.setHotel_BookingNumber("QWERT");
        hotelEntity.setHotel_name("Abccd");
        hotelEntity.setHotel_id(23);

        list.add(hotelEntity);
        return list;
    }

}
