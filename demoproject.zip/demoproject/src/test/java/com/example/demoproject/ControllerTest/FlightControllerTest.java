package com.example.demoproject.ControllerTest;

import com.example.demoproject.Controller.java.FlightController;

import com.example.demoproject.Entity.FlightEntity;
import com.example.demoproject.Service.java.FlightService;
import org.custommonkey.xmlunit.XMLAssert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(FlightController.class)


public class FlightControllerTest {

    @MockBean
    private FlightService flightService;

    @Autowired
    private MockMvc mockMvc;


    @InjectMocks
    private FlightController flightController;

    @Test
    public void TestToGetData() throws Exception {

        List<FlightEntity>list=this.addData();

        Mockito.when(flightService.getDataFlight()).thenReturn(list);

        RequestBuilder requestBuilder = get(
                "/flight").accept(
                MediaType.APPLICATION_XML);
        MvcResult result = this.mockMvc.perform(get("/flight"))
.andExpect(status().isOk())
.andExpect(content().contentType("application/xml;charset=UTF-8"))
.andReturn();


        String xmlExpected="<List>\n" +
                "<item f_id=\"3\">\n" +
                "<f_name>sdfsdf</f_name>\n" +
                "<f_num>sdfsdf</f_num>\n" +
                "<u_name>sfdsd</u_name>\n" +
                "<u_email>sfsdf</u_email>\n" +
                "<uPnr>OL5GB<uPnr/>\n" +
                "</item>\n" +
                "</List>";
       XMLAssert.assertEquals(xmlExpected,result.getResponse().getContentAsString());




    }


    private List<FlightEntity> addData()
    {
        List<FlightEntity> list=new ArrayList<FlightEntity>();
        FlightEntity flightEntity=new FlightEntity();
        flightEntity.setuPnr(null);
        flightEntity.setU_name("abc");
        flightEntity.setU_email("abc@abc.com");
        flightEntity.setF_num("P6GH");
        flightEntity.setF_name("Abcdd");
        list.add(flightEntity);
        return list;
    }
}
