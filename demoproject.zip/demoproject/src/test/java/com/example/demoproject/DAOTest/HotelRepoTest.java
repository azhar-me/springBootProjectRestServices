package com.example.demoproject.DAOTest;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.demoproject.DAORepository.HotelRepo;

import com.example.demoproject.Entity.HotelEntity;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@DataJpaTest
public class HotelRepoTest {

    @Autowired
    private TestEntityManager testEntityManager;

    @Autowired
    private HotelRepo hotelRepo;

    @Test
    public void TestTofindBookingPnrIsNull(){


         testEntityManager.persist(buildHoteltData());
        //HotelEntity hotelEntity =
        /* List<HotelEntity> list=new ArrayList<HotelEntity>();
         list.add(hotelEntity);
        Assert.assertEquals(1,list.size());*/


    }

    private HotelEntity buildHoteltData() {

        HotelEntity hotelEntity=new HotelEntity();
        hotelEntity.setHotel_id(2);
        hotelEntity.setHotel_name("abc");
        hotelEntity.setHotel_BookingNumber(null);
        hotelEntity.setHotel_roomNumber(33);
        hotelEntity.setUser_email("abc@abc.com");
        hotelEntity.setUser_name("pqrs");
        return hotelEntity;

    }
    @Test
    public void showAllData()
    {
        testEntityManager.persistAndFlush(buildHoteltData());
        List<HotelEntity> list=hotelRepo.showAlldata();
        assertThat(list.size()).isEqualTo(1);

    }

}
