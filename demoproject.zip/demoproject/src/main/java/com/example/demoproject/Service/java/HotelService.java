package com.example.demoproject.Service.java;

import com.example.demoproject.DAORepository.HotelRepo;
import com.example.demoproject.Entity.HotelEntity;
import com.example.demoproject.Service.UseCase.HotelServiceUseCase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

@Service
public class HotelService implements HotelServiceUseCase {

    private String generateHotelBookingPnr;
    private Random random;
    private char[] HotelPnr;
    private String values;
    private String numbers;
    private String cap_letters;
    private String Hotel_pnr;
    private List<HotelEntity> list;

    @Autowired
    private HotelRepo hotelRepo;

    @Autowired
    private FlightService flightService;

    public HotelService()
    {
        random=new Random();
        HotelPnr = new char[5];
        cap_letters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        numbers="1234567890";
    }


    @Transactional
    @Override
    public List<HotelEntity> getDataOfHotel() {

        list = hotelRepo.findByNullValues();
        System.out.println("Hotel::"+list.size());
        return list;
    }

    @Transactional
    @Override
    public List<HotelEntity> showAllDataOfHotel() {

        list = hotelRepo.showAlldata();
        System.out.println("Hotel::"+list.size());
        // logger.info("Flight::"+list.size());
        return list;
    }

    @Transactional
    @Override
    public void UpdateDataOfHotel() {

        list = hotelRepo.findByNullValues();
        for(int i=0; i<list.size();i++)
        {
            generateHotelBookingPnr=generateRandomPnr();
            hotelRepo.AddPnrToDatabase(generateHotelBookingPnr,list.get(i).getHotel_id());

        }

    }


         String generateRandomPnr() {
        return flightService.generateRandomPnr();

    }
}
