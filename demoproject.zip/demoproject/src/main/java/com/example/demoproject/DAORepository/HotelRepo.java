package com.example.demoproject.DAORepository;


import com.example.demoproject.Entity.HotelEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HotelRepo  extends JpaRepository<HotelEntity, Integer> {

    @Query(value = "SELECT * FROM hotel_table where h_booking is null ",nativeQuery = true)
    List<HotelEntity> findByNullValues();
   //List<HotelEntity> findByNullValues();

    @Modifying
    @Query(value = "UPDATE hotel_table set h_booking=?1 where h_id=?2 ", nativeQuery = true)
    void AddPnrToDatabase(String pnr,int id);

    @Query(value = "SELECT * FROM hotel_table ",nativeQuery = true)
    List<HotelEntity> showAlldata();

}
