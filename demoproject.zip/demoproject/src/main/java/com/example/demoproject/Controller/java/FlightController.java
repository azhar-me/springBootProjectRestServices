package com.example.demoproject.Controller.java;


import com.example.demoproject.Controller.UseCase.FlightControllerUseCase;

import com.example.demoproject.Entity.FlightEntity;
import com.example.demoproject.Service.java.FlightService;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.logging.Logger;

import static javax.ws.rs.core.MediaType.APPLICATION_XML;


@RestController
public class FlightController implements FlightControllerUseCase {

    private Logger logger;

    @Autowired
    private FlightService flightService;

    private  List<FlightEntity >flightEntityList;

    public FlightController() {
        logger = (Logger)LoggerFactory.getLogger(FlightController.class);
    }

    @Override
        @RequestMapping(value = "/flight",produces = "application/xml")
        public List<FlightEntity> getData()
        {

            List<FlightEntity >flightEntityList=flightService.getDataFlight();
            logger.info("Updating the Pnr");
            flightService.UpdateDataOfFlight();

            return flightEntityList;
        }


    @Override
    @RequestMapping(value = "/flight/update",produces = APPLICATION_XML)
    public List<FlightEntity> data()
    {
        flightEntityList=flightService.showAllDataOfFlight();
        return flightEntityList;
    }

}
