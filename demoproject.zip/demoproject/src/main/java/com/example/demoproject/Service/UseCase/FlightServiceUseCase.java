package com.example.demoproject.Service.UseCase;

import com.example.demoproject.Entity.FlightEntity;

import java.util.List;

public interface FlightServiceUseCase {

        List<FlightEntity> getDataFlight();

        List<FlightEntity> showAllDataOfFlight();

        void UpdateDataOfFlight();

        String generateRandomPnr();
}
