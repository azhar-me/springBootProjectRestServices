package com.example.demoproject.Service.UseCase;



import com.example.demoproject.Entity.HotelEntity;

import java.util.List;

public interface HotelServiceUseCase {
    public List<HotelEntity> getDataOfHotel();
    public List<HotelEntity> showAllDataOfHotel();
    public void UpdateDataOfHotel();

}
