package com.example.demoproject.DAORepository;


import com.example.demoproject.Entity.FlightEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FlightRepo extends JpaRepository<FlightEntity, Integer> {


    public List<FlightEntity> findByUPnrIsNull();

    @Modifying
    @Query(value = "UPDATE flight_table set u_pnr=?1 where f_id=?2 ", nativeQuery = true)
    public void AddPnrToDatabase(String pnr,int id);

    @Query(value = "SELECT * FROM flight_table ",nativeQuery = true)
    public List<FlightEntity> showAlldata();



}
