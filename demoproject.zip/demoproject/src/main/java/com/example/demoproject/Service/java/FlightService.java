package com.example.demoproject.Service.java;

import com.example.demoproject.Entity.FlightEntity;
import com.example.demoproject.DAORepository.FlightRepo;
import com.example.demoproject.Service.UseCase.FlightServiceUseCase;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;
import java.util.logging.Logger;

@Service
public class FlightService implements FlightServiceUseCase {

   // private static final Logger logger= (Logger) LoggerFactory.getLogger(FlightService.class);
    private String generatePnr;
    private Random random;
    private char[] password;
    private String values;
    private String numbers;
    private String cap_letters;
    private String pnr;
    private List<FlightEntity> list;




    public FlightService()
    {
        random=new Random();
        password = new char[5];
        cap_letters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        numbers="1234567890";
    }

    @Autowired
    private FlightRepo flightRepo;

    @Override
    @Scheduled(fixedRate = 15000)
    public List<FlightEntity> getDataFlight() {

        list = flightRepo.findByUPnrIsNull();
        System.out.println("Flight::"+list.size());

        return list;

    }

    @Override
    public List<FlightEntity> showAllDataOfFlight() {
         list = flightRepo.showAlldata();
        System.out.println("Flight::"+list.size());
       // logger.info("Flight::"+list.size());
        return list;

    }

    @Override
    @Transactional
    @Scheduled(cron = "0 0/1 * 1/1 *  *")

    public void UpdateDataOfFlight()
    {
         list = flightRepo.findByUPnrIsNull();

        for(int i=0; i<list.size();i++)
        {
            generatePnr=generateRandomPnr();
            flightRepo.AddPnrToDatabase(generatePnr,list.get(i).getF_id());

        }
    }

        @Override
        public String generateRandomPnr() {

         values=cap_letters+numbers;
         for (int i = 0; i < 5; i++)
             {
                password[i] = values.charAt(random.nextInt(values.length()));

             }
         pnr=new String(password);
         return pnr;

    }

}
