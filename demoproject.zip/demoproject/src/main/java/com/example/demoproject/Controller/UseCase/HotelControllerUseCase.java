package com.example.demoproject.Controller.UseCase;



import com.example.demoproject.Entity.HotelEntity;

import java.util.List;

public interface HotelControllerUseCase {

    public List<HotelEntity> getData();
    public List<HotelEntity> data();
}
