package com.example.demoproject.Entity;


import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "hotel_table")
public class HotelEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "h_id")
    private Integer hotel_id;

    @Column(name = "h_name")
    private String hotel_name;

    @Column(name = "u_name")
    private String user_name;

    @Column(name = "u_email")
    private String user_email;


    @Column(name = "h_booking", nullable = true)
    private String hotel_BookingNumber;

    @Column(name = "h_roomNum")
    private Integer hotel_roomNumber;

    public Integer getHotel_id() {
        return hotel_id;
    }

    public void setHotel_id(Integer hotel_id) {
        this.hotel_id = hotel_id;
    }

    public String getHotel_name() {
        return hotel_name;
    }

    public void setHotel_name(String hotel_name) {
        this.hotel_name = hotel_name;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getHotel_BookingNumber() {
        return hotel_BookingNumber;
    }

    public void setHotel_BookingNumber(String hotel_BookingNumber) {
        this.hotel_BookingNumber = hotel_BookingNumber;
    }

    public Integer getHotel_roomNumber() {
        return hotel_roomNumber;
    }

    public void setHotel_roomNumber(Integer hotel_roomNumber) {
        this.hotel_roomNumber = hotel_roomNumber;
    }
}
