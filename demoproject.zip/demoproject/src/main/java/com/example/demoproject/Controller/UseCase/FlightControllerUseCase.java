package com.example.demoproject.Controller.UseCase;

import com.example.demoproject.Entity.FlightEntity;

import java.util.List;

public interface FlightControllerUseCase {

    public List<FlightEntity> getData();
    public List<FlightEntity> data();

}
