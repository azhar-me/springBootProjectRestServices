package com.example.demoproject.Entity;

import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "flight_table")
    public class FlightEntity implements Serializable {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        @Column(name = "f_id")
        //@JacksonXmlProperty(isAttribute = true)
        private Integer f_id;

        @Column(name = "f_name")
        //@JacksonXmlProperty
        private String f_name;

        @Column(name = "f_num")
        // @JacksonXmlProperty
        private String f_num;

        @Column(name = "u_name")
        //@JacksonXmlProperty
        private String u_name;

        @Column(name = "u_email")
        // @JacksonXmlProperty
        private String u_email;


        @Column(name = "u_pnr", nullable = true)
        //@JacksonXmlProperty
        private String uPnr;

        public int getF_id() {
            return f_id;
        }

        public void setF_id(int f_id) {
            this.f_id = f_id;
        }

        public String getF_name() {
            return f_name;
        }

        public void setF_name(String f_name) {
            this.f_name = f_name;
        }

        public String getF_num() {
            return f_num;
        }

        public void setF_num(String f_num) {
            this.f_num = f_num;
        }

        public String getU_name() {
            return u_name;
        }

        public void setU_name(String u_name) {
            this.u_name = u_name;
        }

        public String getU_email() {
            return u_email;
        }

        public void setU_email(String u_email) {
            this.u_email = u_email;
        }

        public String getuPnr() {
            return uPnr;
        }

        public void setuPnr(String uPnr) {
            this.uPnr = uPnr;
        }


    }

