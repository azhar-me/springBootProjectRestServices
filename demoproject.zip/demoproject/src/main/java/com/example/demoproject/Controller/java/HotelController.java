package com.example.demoproject.Controller.java;

import com.example.demoproject.Controller.UseCase.HotelControllerUseCase;
import com.example.demoproject.Entity.HotelEntity;
import com.example.demoproject.Service.java.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@RestController
public class HotelController implements HotelControllerUseCase {

    @Autowired
    private HotelService hotelService;

    private List<HotelEntity> hotelEntityList;

    @Override
    @RequestMapping(value = "/hotel", produces = APPLICATION_JSON)
    public List<HotelEntity> getData() {
        List<HotelEntity> hotelEntityList = hotelService.getDataOfHotel();
        hotelService. UpdateDataOfHotel();
        return hotelEntityList;
    }


    @Override
    @RequestMapping(value = "/hotel/update", produces = APPLICATION_JSON)
    public List<HotelEntity> data() {
        hotelEntityList = hotelService.showAllDataOfHotel();
        return hotelEntityList;
    }
}
